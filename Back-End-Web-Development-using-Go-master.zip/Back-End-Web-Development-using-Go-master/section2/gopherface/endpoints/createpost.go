package endpoints

import "net/http"

func CreatePostEndpoint(w http.ResponseWriter, r *http.Request) {

	// TODO: Implement the create post endpoint

}
