package endpoints

import "net/http"

func DeletePostEndpoint(w http.ResponseWriter, r *http.Request) {

	// TODO: Implement the delete post endpoint

}
