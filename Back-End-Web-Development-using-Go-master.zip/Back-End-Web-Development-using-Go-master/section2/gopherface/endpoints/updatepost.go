package endpoints

import "net/http"

func UpdatePostEndpoint(w http.ResponseWriter, r *http.Request) {

	// TODO: Implement the update post endpoint

}
