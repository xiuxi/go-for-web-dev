This directory will store uploaded image files.
