This directory will store uploaded video files.
