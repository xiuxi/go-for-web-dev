package common

import "github.com/EngineerKamesh/gofullstack/volume2/section5/gopherfacedb/common/datastore"

type Env struct {
	DB datastore.Datastore
}
