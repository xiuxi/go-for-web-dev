package asyncq

type Task interface {
	Perform()
}
