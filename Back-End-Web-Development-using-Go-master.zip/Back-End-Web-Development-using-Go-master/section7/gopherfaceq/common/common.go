package common

import "github.com/EngineerKamesh/gofullstack/volume2/section7/gopherfaceq/common/datastore"

type Env struct {
	DB datastore.Datastore
}
